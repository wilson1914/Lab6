var anchorTag = document.createElement('a');

anchorTag.innerHTML = '<a href="http://www.google.com">Go</a>';
document.body.appendChild(anchorTag);