alert(you got this)

var temperature = "65";
var event = "casual";

if (temperature>65){
	console.log ("Don't wear a jacket");
}

else if (event) {
	console.log ("Wear a jacket");
}

else {
	console.log ("Don't go to the event");
}


var temp = "56";