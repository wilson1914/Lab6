alert('hi');
console.log ('Fahrenheit to Celsius');


var Fahrenheit = '56';
var conversion = '/2-30';
var result = Fahrenheit + conversion;
console.log(result);